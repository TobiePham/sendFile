echo "# Amending minified assets to HEAD"

git add ./dist/purify.js ./dist/purify.js.map ./dist/purify.min.js ./dist/purify.min.js.map ./dist/purify.cjs.js ./dist/purify.cjs.js.map ./dist/purify.es.mjs ./dist/purify.es.mjs.map
