export class PDFSinglePageViewer extends PDFViewer {
    set scrollMode(arg: any);
    _updateScrollMode(): void;
    set spreadMode(arg: any);
    _updateSpreadMode(): void;
}
import { PDFViewer } from "./pdf_viewer.js";
