export const isNodeJS: any;
