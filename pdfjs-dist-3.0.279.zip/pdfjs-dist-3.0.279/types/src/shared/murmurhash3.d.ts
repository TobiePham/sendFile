export class MurmurHash3_64 {
    constructor(seed: any);
    h1: number;
    h2: number;
    update(input: any): void;
    hexdigest(): string;
}
